package com.example.emapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Signin extends AppCompatActivity {
  //step 1 - Creatinginstances/variables
 TextView t1;
    EditText loginemail,loginpassword;
    Button loginbtn;
    FirebaseAuth f1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        //Step 2 - Linking or casting objects to xml controls
        t1 = findViewById(R.id.newuserpage);
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Signin.this, signup.class);
                startActivity(i);
            }
        });
        f1=FirebaseAuth.getInstance();
        loginemail = findViewById(R.id.loginemail);
        loginpassword = findViewById(R.id.loginpass);
        loginbtn = findViewById(R.id.loginbtn);
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user_email = loginemail.getText().toString();
                String user_pass = loginpassword.getText().toString();
                f1.signInWithEmailAndPassword(user_email,user_pass).addOnSuccessListener(Signin.this, new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        Toast.makeText(Signin.this,"LOGIN SUCCESSFULL!!",Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Signin.this, homepage.class));
                    }
                });
            }
        });




    }
}